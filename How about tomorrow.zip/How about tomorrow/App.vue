<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	@font-face {
	  font-family: "iconfont"; /* Project id 4378713 */
	  src: url('//at.alicdn.com/t/c/font_4378713_m4xszdnfwmn.woff2?t=1702895890429') format('woff2'),
	       url('//at.alicdn.com/t/c/font_4378713_m4xszdnfwmn.woff?t=1702895890429') format('woff'),
	       url('//at.alicdn.com/t/c/font_4378713_m4xszdnfwmn.ttf?t=1702895890429') format('truetype');
	}
	
	.iconfont {
	  font-family: "iconfont" !important;
	  font-size: 16px;
	  font-style: normal;
	  -webkit-font-smoothing: antialiased;
	  -moz-osx-font-smoothing: grayscale;
	}
	
	.icon-baoyu:before {
	  content: "\e62d";
	}
	
	.icon-zhongyu:before {
	  content: "\e62e";
	}
	
	.icon-yin:before {
	  content: "\e62f";
	}
	
	.icon-youyun:before {
	  content: "\e630";
	}
	
	.icon-leizhenyu:before {
	  content: "\e631";
	}
	
	.icon-dingxiang:before {
	  content: "\e600";
	}
	
	.icon-yundong:before {
	  content: "\e807";
	}
	
	.icon-kongqiqingxin:before {
	  content: "\e697";
	}
	
	.icon-sousuo:before {
	  content: "\e623";
	}
	
	.icon-lvyou:before {
	  content: "\e60c";
	}
	
	.icon-shangchang:before {
	  content: "\e633";
	}
	
	.icon-icon_tianjia:before {
	  content: "\eb89";
	}
	
	.icon-xinqingyiban-yuan:before {
	  content: "\e7d0";
	}
	
	.icon-tianqi-fengxiang:before {
	  content: "\e679";
	}
	
	.icon-yifu:before {
	  content: "\e696";
	}
	
	.icon-yusan:before {
	  content: "\e698";
	}
	
	.icon-shushi:before {
	  content: "\e634";
	}
	
	.icon-kongtiao:before {
	  content: "\e617";
	}
	
	.icon-kongqiwendu:before {
	  content: "\eb3a";
	}
	
	.icon-kongqizhiliangjiance:before {
	  content: "\e632";
	}
	
	.icon-kongqizhiliangfenxi:before {
	  content: "\ec97";
	}
	
	.icon-xiangxia:before {
	  content: "\e796";
	}
	
	.icon-diaoyu:before {
	  content: "\e650";
	}
	
	.icon-fangshaishuang-01:before {
	  content: "\e607";
	}
	
	.icon-shuidibeifen:before {
	  content: "\e612";
	}
	
	.icon-ziwaixianxiaodu:before {
	  content: "\e6cf";
	}
	
	.icon-duoyun:before {
	  content: "\e628";
	}
	
	.icon-qing:before {
	  content: "\e629";
	}
	
	.icon-xiaoyu:before {
	  content: "\e62a";
	}
	
	.icon-dayu:before {
	  content: "\e62b";
	}
	
	.icon-qingzhuanduoyun:before {
	  content: "\e62c";
	}

</style>
