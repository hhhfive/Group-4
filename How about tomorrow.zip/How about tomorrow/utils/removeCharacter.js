export function removeCharacter(inputString, characterToRemove) {
	
}