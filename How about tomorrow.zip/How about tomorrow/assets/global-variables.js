// 高德
const gaodeKey = '3e2e5507241604c1766dc888714895ca'

// 免费天气api
const appid = '49256527'
const appsecret = '1gzSHFWM&ext'


export {
	gaodeKey,
	appid,
	appsecret,
}